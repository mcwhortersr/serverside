from django.contrib import admin
from schedules.models import Term, Room, Course, Section, MeetingAssignment, Instructor

admin.site.register(Term)
admin.site.register(Room)
admin.site.register(Course)
admin.site.register(Section)
admin.site.register(MeetingAssignment)
admin.site.register(Instructor)
