from django.conf.urls import url

from schedules.views import RoomListView, CourseListView, CourseDetailView, CourseCreateView
from schedules.views import CourseUpdateView, CourseDeleteView, SectionListView

urlpatterns = [
    url(r'^room/$', RoomListView.as_view(), name='room-list'),
    url(r'^course/$', CourseListView.as_view(), name='course-list'),
    url(r'^course/(?P<pk>\d+)/$', CourseDetailView.as_view(), name='course-detail'),
    url(r'^course/add/$', CourseCreateView.as_view(), name='course-add'),
    url(r'^course/modify/(?P<pk>\d+)/$', CourseUpdateView.as_view(), name='course-modify'),
    url(r'^course/delete/(?P<pk>\d+)/$', CourseDeleteView.as_view(), name='course-delete'),
    url(r'^section/$', SectionListView.as_view(), name='section-list'),
]
