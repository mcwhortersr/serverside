from django.db import models
from django.core.urlresolvers import reverse

ROOM_TYPES = (
    ("A", "Lecture"),
    ("B", "Large Lecture"),
    ("C", "Lab"),
    ("D", "Other"),
)

COURSE_TYPES = (
    ("A", "Lecture"),
    ("B", "Lab"),
    ("C", "Online"),
    ("D", "Other"),
)

DAY_NAMES = (
    ("A", "Sunday"),
    ("B", "Monday"),
    ("C", "Tuesday"),
    ("D", "Wednesday"),
    ("E", "Thursday"),
    ("F", "Friday"),
    ("G", "Saturday"),
)

class Term(models.Model):
    SEMESTER_NAMES = (
        ('SP', 'Spring'),
        ('S1', 'Summer1'),
        ('S2', 'Summer2'),
        ('S3', 'Summer'),
        ('FA', 'Fall'),
    )
    year = models.IntegerField()
    semester = models.CharField(max_length=2, choices=SEMESTER_NAMES)
    current = models.BooleanField()

    def __str__(self):
        return str(self.year) + " " + self.get_semester_display()

class Room(models.Model):
    building = models.CharField(max_length=40)
    building_abbr = models.CharField(max_length=3)
    room_number = models.CharField(max_length=10)
    capacity = models.IntegerField()
    type = models.CharField(max_length=1, choices=ROOM_TYPES)
    comments = models.TextField()
    available = models.TextField()

    def __str__(self):
        return self.building + " " + self.room_number

class Course(models.Model):
    discipline = models.CharField(max_length=4)
    course_number = models.IntegerField()
    type = models.CharField(max_length=1, choices=COURSE_TYPES)
    title = models.CharField(max_length=60)
    description = models.TextField()
    conflicts_warn = models.ManyToManyField('self', null=True, default=None, blank=True)
    credit = models.IntegerField()
    contact = models.IntegerField()
    sections = models.IntegerField()
    control = models.BooleanField()

    def __str__(self):
        return self.discipline + " " + str(self.course_number) + " " + self.get_type_display()
    def get_absolute_url(self):
        return reverse('course-detail', kwargs={'pk': self.pk})

class MeetingAssignment(models.Model):
    day = models.CharField(max_length=1, choices=DAY_NAMES)
    time = models.FloatField()
    duration = models.FloatField()
    term = models.ForeignKey(Term, null=True, default=None, blank=True)
    room = models.ForeignKey(Room, null=True, default=None, blank=True)

    def __str__(self):
        return self.get_day_display() + " " + str(self.time) + " " + str(self.duration) + " " + str(self.room)

class Instructor(models.Model):
    title = models.CharField(max_length=20)
    name = models.CharField(max_length=50)
    preferences = models.TextField()
    RequestedCourses = models.ManyToManyField(Course, null=True, default=None, blank=True)

    def __str__(self):
        return self.name

class Section(models.Model):
    term = models.ForeignKey(Term, null=True, default=None, blank=True)
    course = models.ForeignKey(Course, null=True, default=None, blank=True)
    instructor = models.ForeignKey(Instructor, null=True, default=None, blank=True) 
    number = models.IntegerField()
    meeting_assignment = models.ManyToManyField(MeetingAssignment, null=True, default=None, blank=True)
    room_type = models.CharField(max_length=1, choices=ROOM_TYPES)
    seats_required = models.IntegerField()

    def __str__(self):
        return str(self.course) + " " + str(self.number)

