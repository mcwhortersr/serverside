from django.core.urlresolvers import reverse_lazy
from django.views.generic.list import ListView
from django.views.generic import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView

from schedules.models import Room, Course, Section, Term

class RoomListView(ListView):
    model = Room
    fields = ['building_abbr', 'room_number', 'capacity', 'type', 'available']
    queryset = Room.objects.order_by('building_abbr', 'room_number')

class CourseListView(ListView):
    model = Course
    fields = ['discipline', 'course_number', 'type', 'title', 'description',
              'conflicts_warn', 'credit', 'contact', 'sections', 'control']
    queryset = Course.objects.order_by('discipline', 'course_number', 'type')

class CourseDetailView(DetailView):
    model = Course
    fields = ['discipline', 'course_number', 'type', 'title', 'description',
              'conflicts_warn', 'credit', 'contact', 'sections', 'control']

class CourseCreateView(CreateView):
    model = Course
    fields = ['discipline', 'course_number', 'type', 'title', 'description',
              'conflicts_warn', 'credit', 'contact', 'sections', 'control']

class CourseUpdateView(UpdateView):
    model = Course
    fields = ['discipline', 'course_number', 'type', 'title', 'description',
              'conflicts_warn', 'credit', 'contact', 'sections', 'control']
    template_name_suffix = '_update_form'

class CourseDeleteView(DeleteView):
    model = Course
    success_url = reverse_lazy('course-list')

class SectionListView(ListView):
   model = Section
   fields = ['term', 'course', 'instructor', 'number', 'meeting_assignment',
             'room_type', 'seats_required']
   current_term = Term.objects.get(current=True)
   queryset = Section.objects.filter(term=current_term).order_by('course', 'number')
   def get_context_data(self, **kwargs):
      context = super(SectionListView, self).get_context_data(**kwargs)
      for section in context['object_list']:
         section.credit = section.course.credit
         total_time = 0
         meetings = section.meeting_assignment.all()
         if len(meetings) == 0:
            section.css_class = 'notscheduled'
         else:
            section.css_class = 'scheduled'
         for m in meetings:
            total_time += m.duration
         section.total_time = total_time
      return context
