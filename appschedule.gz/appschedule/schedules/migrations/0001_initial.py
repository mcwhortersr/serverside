# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Course',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('discipline', models.CharField(max_length=4)),
                ('course_number', models.IntegerField()),
                ('type', models.CharField(max_length=1, choices=[('A', 'Lecture'), ('B', 'Lab'), ('C', 'Online'), ('D', 'Other')])),
                ('title', models.CharField(max_length=60)),
                ('description', models.TextField()),
                ('credit', models.IntegerField()),
                ('contact', models.IntegerField()),
                ('sections', models.IntegerField()),
                ('control', models.BooleanField()),
                ('conflicts_warn', models.ManyToManyField(default=None, related_name='conflicts_warn_rel_+', null=True, to='schedules.Course', blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Instructor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=20)),
                ('name', models.CharField(max_length=50)),
                ('preferences', models.TextField()),
                ('RequestedCourses', models.ManyToManyField(default=None, to='schedules.Course', null=True, blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='MeetingAssignment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('day', models.CharField(max_length=1, choices=[('A', 'Sunday'), ('B', 'Monday'), ('C', 'Tuesday'), ('D', 'Wednesday'), ('E', 'Thursday'), ('F', 'Friday'), ('G', 'Saturday')])),
                ('time', models.FloatField()),
                ('duration', models.FloatField()),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Room',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('building', models.CharField(max_length=40)),
                ('building_abbr', models.CharField(max_length=3)),
                ('room_number', models.CharField(max_length=10)),
                ('capacity', models.IntegerField()),
                ('type', models.CharField(max_length=1, choices=[('A', 'Lecture'), ('B', 'Large Lecture'), ('C', 'Lab'), ('D', 'Other')])),
                ('comments', models.TextField()),
                ('available', models.TextField()),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Section',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('number', models.IntegerField()),
                ('room_type', models.CharField(max_length=1, choices=[('A', 'Lecture'), ('B', 'Large Lecture'), ('C', 'Lab'), ('D', 'Other')])),
                ('seats_required', models.IntegerField()),
                ('course', models.ForeignKey(default=None, blank=True, to='schedules.Course', null=True)),
                ('instructor', models.ForeignKey(default=None, blank=True, to='schedules.Instructor', null=True)),
                ('meeting_assignment', models.ManyToManyField(default=None, to='schedules.MeetingAssignment', null=True, blank=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Term',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('year', models.IntegerField()),
                ('semester', models.CharField(max_length=2, choices=[('SP', 'Spring'), ('S1', 'Summer1'), ('S2', 'Summer2'), ('S3', 'Summer'), ('FA', 'Fall')])),
                ('current', models.BooleanField()),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='section',
            name='term',
            field=models.ForeignKey(default=None, blank=True, to='schedules.Term', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='meetingassignment',
            name='room',
            field=models.ForeignKey(default=None, blank=True, to='schedules.Room', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='meetingassignment',
            name='term',
            field=models.ForeignKey(default=None, blank=True, to='schedules.Term', null=True),
            preserve_default=True,
        ),
    ]
